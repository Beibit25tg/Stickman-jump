from kivy.logger import Logger
from kivy.clock import Clock
from kivy.utils import platform
from kivy.event import EventDispatcher

# Проверка, запущено ли приложение на Android
if platform == 'android':
    try:
        from kivmob import KivMob, TestIds
        is_android = True
    except ImportError:
        Logger.warning("AdManager: KivMob не найден, используется заглушка")
        is_android = False
else:
    is_android = False

class AdManager(EventDispatcher):
    """
    Класс для управления рекламой AdMob в приложении
    """
    
    def __init__(self, app_id=None):
        """
        Инициализирует менеджер рекламы
        
        :param app_id: Идентификатор приложения AdMob
        """
        super(AdManager, self).__init__()
        self.ready = False
        self.ads_removed = False
        self.app_id = app_id or "ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY"  # Заменить на реальный ID
        self.banner_id = TestIds.BANNER
        self.interstitial_id = TestIds.INTERSTITIAL
        self.rewarded_id = TestIds.REWARDED_VIDEO
        self.callback = None
        
        # Инициализация KivMob для Android
        if is_android:
            self.kivmob = KivMob(self.app_id)
            self.init_ads()
        else:
            Logger.info("AdManager: Запуск в режиме имитации рекламы (не Android)")
            Clock.schedule_once(self._dummy_init, 1)
    
    def init_ads(self):
        """Инициализирует все типы рекламы"""
        if not is_android:
            return
            
        # Инициализация баннера
        self.kivmob.new_banner(self.banner_id, top_pos=False)
        
        # Инициализация межстраничной рекламы
        self.kivmob.new_interstitial(self.interstitial_id)
        self.kivmob.request_interstitial()
        
        # Инициализация рекламы с вознаграждением
        self.kivmob.new_rewarded_ad(self.rewarded_id)
        self.kivmob.load_rewarded_ad()
        
        self.ready = True
    
    def _dummy_init(self, dt):
        """Имитация инициализации рекламы для отладки"""
        self.ready = True
        Logger.info("AdManager: Имитация рекламы готова")
    
    def set_ads_removed(self, removed):
        """
        Устанавливает флаг удаления рекламы (для покупки 'без рекламы')
        
        :param removed: True если реклама должна быть удалена
        """
        self.ads_removed = removed
    
    def show_banner(self):
        """Показывает баннерную рекламу"""
        if self.ads_removed or not self.ready:
            return
            
        if is_android:
            self.kivmob.show_banner()
            Logger.info("AdManager: Показ баннерной рекламы")
        else:
            Logger.info("AdManager: Имитация показа баннерной рекламы")
    
    def hide_banner(self):
        """Скрывает баннерную рекламу"""
        if not self.ready:
            return
            
        if is_android:
            self.kivmob.hide_banner()
            Logger.info("AdManager: Скрытие баннерной рекламы")
        else:
            Logger.info("AdManager: Имитация скрытия баннерной рекламы")
    
    def show_interstitial(self):
        """Показывает межстраничную рекламу"""
        if self.ads_removed or not self.ready:
            return False
            
        if is_android:
            if self.kivmob.is_interstitial_loaded():
                self.kivmob.show_interstitial()
                Logger.info("AdManager: Показ межстраничной рекламы")
                # Запрашиваем новую рекламу для следующего показа
                Clock.schedule_once(lambda dt: self.kivmob.request_interstitial(), 1)
                return True
            else:
                Logger.warning("AdManager: Межстраничная реклама не загружена")
                # Попытка загрузить рекламу
                self.kivmob.request_interstitial()
                return False
        else:
            Logger.info("AdManager: Имитация показа межстраничной рекламы")
            return True
    
    def show_rewarded_ad(self, callback=None):
        """
        Показывает рекламу с вознаграждением
        
        :param callback: Функция, вызываемая после успешного просмотра рекламы
        :return: True если реклама показана, иначе False
        """
        if not self.ready:
            return False
            
        self.callback = callback
        
        if is_android:
            if self.kivmob.is_rewarded_ad_loaded():
                # Устанавливаем callback для получения вознаграждения
                def on_rewarded(reward_name, reward_amount):
                    Logger.info(f"AdManager: Получена награда: {reward_name}, {reward_amount}")
                    if self.callback:
                        self.callback()
                
                self.kivmob.set_rewarded_ad_callback(on_rewarded)
                self.kivmob.show_rewarded_ad()
                Logger.info("AdManager: Показ рекламы с вознаграждением")
                
                # Загружаем новую рекламу для следующего показа
                Clock.schedule_once(lambda dt: self.kivmob.load_rewarded_ad(), 1)
                return True
            else:
                Logger.warning("AdManager: Реклама с вознаграждением не загружена")
                # Пытаемся загрузить рекламу
                self.kivmob.load_rewarded_ad()
                return False
        else:
            Logger.info("AdManager: Имитация показа рекламы с вознаграждением")
            if callback:
                Clock.schedule_once(lambda dt: callback(), 2)
            return True
