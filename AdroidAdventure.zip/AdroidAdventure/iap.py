from kivy.utils import platform
from kivy.logger import Logger
from kivy.event import EventDispatcher
from kivy.clock import Clock

# Проверяем, запущены ли мы на Android
if platform == 'android':
    try:
        # Импорт библиотеки для работы с Google Play Billing
        from jnius import autoclass
        
        Activity = autoclass('org.kivy.android.PythonActivity')
        PythonActivity = Activity.mActivity
        
        BillingClient = autoclass('com.android.billingclient.api.BillingClient')
        BillingFlowParams = autoclass('com.android.billingclient.api.BillingFlowParams')
        SkuDetailsParams = autoclass('com.android.billingclient.api.SkuDetailsParams')
        Purchase = autoclass('com.android.billingclient.api.Purchase')
        
        BillingClientStateListener = autoclass('com.android.billingclient.api.BillingClientStateListener')
        SkuDetailsResponseListener = autoclass('com.android.billingclient.api.SkuDetailsResponseListener')
        PurchasesUpdatedListener = autoclass('com.android.billingclient.api.PurchasesUpdatedListener')
        
        ArrayList = autoclass('java.util.ArrayList')
        
        is_android = True
    except ImportError:
        Logger.warning("IAP: Ошибка импорта библиотек для IAP на Android")
        is_android = False
else:
    is_android = False

class PurchaseResult:
    SUCCESS = 'success'
    FAILED = 'failed'
    CANCELLED = 'cancelled'
    ALREADY_OWNED = 'already_owned'
    PENDING = 'pending'

class IAPManager(EventDispatcher):
    """
    Класс для управления внутриигровыми покупками Google Play
    """
    
    def __init__(self):
        """Инициализирует менеджер внутриигровых покупок"""
        super(IAPManager, self).__init__()
        self.ready = False
        self.billing_client = None
        self.sku_details = {}
        self.callback = None
        
        # ID продуктов
        self.product_ids = {
            'no_ads': 'com.your.gamename.remove_ads',
            'coins_100': 'com.your.gamename.coins_100',
            'coins_500': 'com.your.gamename.coins_500',
            'premium_skin': 'com.your.gamename.premium_skin',
            'extra_lives': 'com.your.gamename.extra_lives'
        }
        
        if is_android:
            self._init_billing()
        else:
            Logger.info("IAP: Работа в режиме имитации покупок (не Android)")
            Clock.schedule_once(self._dummy_init, 1)
    
    def _init_billing(self):
        """Инициализация Google Play Billing"""
        if not is_android:
            return
        
        try:
            # Создаем слушатель обновления покупок
            class PurchasesListener(PurchasesUpdatedListener):
                def __init__(self, manager):
                    self.manager = manager
                    PurchasesUpdatedListener.__init__(self)
                
                def onPurchasesUpdated(self, billingResult, purchases):
                    response_code = billingResult.getResponseCode()
                    if response_code == BillingClient.BillingResponseCode.OK:
                        if purchases:
                            for purchase in purchases:
                                self.manager._handle_purchase(purchase)
                        else:
                            Logger.info("IAP: Покупки обновлены, но пусты")
                            if self.manager.callback:
                                self.manager.callback(PurchaseResult.SUCCESS, None)
                    elif response_code == BillingClient.BillingResponseCode.USER_CANCELED:
                        Logger.info("IAP: Пользователь отменил покупку")
                        if self.manager.callback:
                            self.manager.callback(PurchaseResult.CANCELLED, None)
                    elif response_code == BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED:
                        Logger.info("IAP: Товар уже куплен")
                        if self.manager.callback:
                            self.manager.callback(PurchaseResult.ALREADY_OWNED, None)
                    else:
                        Logger.warning(f"IAP: Ошибка покупки, код: {response_code}")
                        if self.manager.callback:
                            self.manager.callback(PurchaseResult.FAILED, None)
            
            # Создаем слушателя состояния подключения
            class BillingStateListener(BillingClientStateListener):
                def __init__(self, manager):
                    self.manager = manager
                    BillingClientStateListener.__init__(self)
                
                def onBillingSetupFinished(self, billingResult):
                    response_code = billingResult.getResponseCode()
                    if response_code == BillingClient.BillingResponseCode.OK:
                        Logger.info("IAP: Billing настроен успешно")
                        self.manager.ready = True
                        self.manager._query_skus()
                    else:
                        Logger.warning(f"IAP: Ошибка настройки Billing, код: {response_code}")
                
                def onBillingServiceDisconnected(self):
                    Logger.warning("IAP: Соединение с сервисом Billing разорвано")
                    self.manager.ready = False
            
            # Инициализация Billing Client
            self.purchases_listener = PurchasesListener(self)
            self.billing_client = BillingClient.newBuilder(PythonActivity) \
                .setListener(self.purchases_listener) \
                .enablePendingPurchases() \
                .build()
            
            # Подключение к сервису
            self.billing_client.startConnection(BillingStateListener(self))
        except Exception as e:
            Logger.error(f"IAP: Ошибка инициализации Billing: {e}")
    
    def _dummy_init(self, dt):
        """Имитация инициализации покупок для отладки"""
        self.ready = True
        self.sku_details = {
            'no_ads': {'price': '2.99 $', 'title': 'Убрать рекламу'},
            'coins_100': {'price': '0.99 $', 'title': '100 монет'},
            'coins_500': {'price': '4.99 $', 'title': '500 монет'},
            'premium_skin': {'price': '1.99 $', 'title': 'Премиум скин'},
            'extra_lives': {'price': '1.49 $', 'title': 'Дополнительные жизни'}
        }
        Logger.info("IAP: Имитация покупок готова")
    
    def _query_skus(self):
        """Запрашивает информацию о продуктах из Google Play"""
        if not is_android or not self.ready:
            return
        
        try:
            # Создаем список ID продуктов
            skuList = ArrayList()
            for product_id in self.product_ids.values():
                skuList.add(product_id)
            
            # Создаем параметры запроса
            params = SkuDetailsParams.newBuilder() \
                .setSkusList(skuList) \
                .setType(BillingClient.SkuType.INAPP) \
                .build()
            
            # Создаем слушателя для ответа
            class SkuDetailsListener(SkuDetailsResponseListener):
                def __init__(self, manager):
                    self.manager = manager
                    SkuDetailsResponseListener.__init__(self)
                
                def onSkuDetailsResponse(self, billingResult, skuDetailsList):
                    response_code = billingResult.getResponseCode()
                    if response_code == BillingClient.BillingResponseCode.OK:
                        if skuDetailsList:
                            for skuDetails in skuDetailsList:
                                sku_id = skuDetails.getSku()
                                # Находим нашу ключевую строку по значению ID
                                key = None
                                for k, v in self.manager.product_ids.items():
                                    if v == sku_id:
                                        key = k
                                        break
                                
                                if key:
                                    self.manager.sku_details[key] = {
                                        'sku_details_obj': skuDetails,
                                        'price': skuDetails.getPrice(),
                                        'title': skuDetails.getTitle(),
                                        'description': skuDetails.getDescription()
                                    }
                            Logger.info(f"IAP: Получены данные о {len(skuDetailsList)} продуктах")
                        else:
                            Logger.warning("IAP: Список продуктов пуст")
                    else:
                        Logger.warning(f"IAP: Ошибка получения списка продуктов, код: {response_code}")
            
            # Запрашиваем информацию о продуктах
            self.billing_client.querySkuDetailsAsync(params, SkuDetailsListener(self))
        except Exception as e:
            Logger.error(f"IAP: Ошибка запроса информации о продуктах: {e}")
    
    def _handle_purchase(self, purchase):
        """
        Обработка покупки
        
        :param purchase: Объект покупки
        """
        if not is_android:
            return
        
        try:
            purchase_state = purchase.getPurchaseState()
            if purchase_state == Purchase.PurchaseState.PURCHASED:
                # Проверяем, подтверждена ли покупка
                if not purchase.isAcknowledged():
                    self._acknowledge_purchase(purchase)
                
                sku = purchase.getSkus().get(0)
                Logger.info(f"IAP: Успешная покупка {sku}")
                
                # Находим наш ключ по значению ID
                product_key = None
                for k, v in self.product_ids.items():
                    if v == sku:
                        product_key = k
                        break
                
                # Вызываем коллбэк с информацией о покупке
                if self.callback:
                    self.callback(PurchaseResult.SUCCESS, product_key)
            elif purchase_state == Purchase.PurchaseState.PENDING:
                Logger.info("IAP: Покупка в ожидании")
                if self.callback:
                    self.callback(PurchaseResult.PENDING, None)
            else:
                Logger.warning(f"IAP: Неизвестное состояние покупки: {purchase_state}")
                if self.callback:
                    self.callback(PurchaseResult.FAILED, None)
        except Exception as e:
            Logger.error(f"IAP: Ошибка обработки покупки: {e}")
            if self.callback:
                self.callback(PurchaseResult.FAILED, None)
    
    def _acknowledge_purchase(self, purchase):
        """
        Подтверждает покупку
        
        :param purchase: Объект покупки
        """
        if not is_android:
            return
        
        try:
            acknowledgePurchaseParams = autoclass('com.android.billingclient.api.AcknowledgePurchaseParams') \
                .newBuilder() \
                .setPurchaseToken(purchase.getPurchaseToken()) \
                .build()
            
            class AcknowledgeListener(autoclass('com.android.billingclient.api.AcknowledgePurchaseResponseListener')):
                def __init__(self):
                    super(AcknowledgeListener, self).__init__()
                
                def onAcknowledgePurchaseResponse(self, billingResult):
                    response_code = billingResult.getResponseCode()
                    if response_code == BillingClient.BillingResponseCode.OK:
                        Logger.info("IAP: Покупка подтверждена успешно")
                    else:
                        Logger.warning(f"IAP: Ошибка подтверждения покупки, код: {response_code}")
            
            self.billing_client.acknowledgePurchase(acknowledgePurchaseParams, AcknowledgeListener())
        except Exception as e:
            Logger.error(f"IAP: Ошибка подтверждения покупки: {e}")
    
    def get_product_price(self, product_key):
        """
        Возвращает цену продукта
        
        :param product_key: Ключ продукта
        :return: Строка с ценой или None
        """
        if product_key in self.sku_details:
            return self.sku_details[product_key].get('price', 'N/A')
        return 'N/A'
    
    def get_product_title(self, product_key):
        """
        Возвращает название продукта
        
        :param product_key: Ключ продукта
        :return: Строка с названием или None
        """
        if product_key in self.sku_details:
            return self.sku_details[product_key].get('title', product_key)
        return product_key
    
    def purchase(self, product_key, callback=None):
        """
        Запускает процесс покупки
        
        :param product_key: Ключ продукта
        :param callback: Функция обратного вызова (result, product_key)
        :return: True если процесс запущен, False если ошибка
        """
        self.callback = callback
        
        if not is_android:
            Logger.info(f"IAP: Имитация покупки {product_key}")
            if callback:
                Clock.schedule_once(lambda dt: callback(PurchaseResult.SUCCESS, product_key), 2)
            return True
        
        if not self.ready:
            Logger.warning("IAP: Billing не готов")
            if callback:
                callback(PurchaseResult.FAILED, None)
            return False
        
        if product_key not in self.sku_details:
            Logger.warning(f"IAP: Продукт {product_key} не найден")
            if callback:
                callback(PurchaseResult.FAILED, None)
            return False
        
        try:
            sku_details = self.sku_details[product_key]['sku_details_obj']
            params = BillingFlowParams.newBuilder() \
                .setSkuDetails(sku_details) \
                .build()
            
            result = self.billing_client.launchBillingFlow(PythonActivity, params)
            response_code = result.getResponseCode()
            
            if response_code == BillingClient.BillingResponseCode.OK:
                Logger.info(f"IAP: Запущен процесс покупки {product_key}")
                return True
            else:
                Logger.warning(f"IAP: Ошибка запуска покупки, код: {response_code}")
                if callback:
                    callback(PurchaseResult.FAILED, None)
                return False
        except Exception as e:
            Logger.error(f"IAP: Ошибка покупки: {e}")
            if callback:
                callback(PurchaseResult.FAILED, None)
            return False
