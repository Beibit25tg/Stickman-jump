from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen, FadeTransition
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.slider import Slider
from kivy.core.audio import SoundLoader
from kivy.lang import Builder
from kivy.uix.widget import Widget
from kivy.uix.image import Image
from kivy.uix.popup import Popup
from kivy.clock import Clock
from kivy.properties import NumericProperty, StringProperty
from kivy.core.window import Window
from kivy.utils import platform
from kivy.logger import Logger
from random import randint
from langs import LANGUAGES
from ads import AdManager
from iap import IAPManager, PurchaseResult
from store import GameStore

# Глобальные настройки
current_lang = 'ru'  # начнем с русского
volume_music = 0.5
volume_sfx = 0.5

# KV код для UI
Builder.load_string("""
<MainMenuScreen>:
    BoxLayout:
        orientation: 'vertical'
        spacing: dp(20)
        padding: dp(30)
        
        Label:
            text: 'Stickman Jumper'
            font_size: '30sp'
            size_hint_y: None
            height: dp(60)
        
        Label:
            text: root.coins_text
            font_size: '20sp'
            size_hint_y: None
            height: dp(40)
        
        BoxLayout:
            orientation: 'vertical'
            spacing: dp(10)
            size_hint_y: None
            height: self.minimum_height
            pos_hint: {"center_x": 0.5}
            
            Button:
                text: root.get_text('play')
                background_color: (0, 1, 0, 1)
                font_size: '24sp'
                size_hint: (0.8, None)
                height: dp(60)
                pos_hint: {"center_x": 0.5}
                on_release: root.play_game()
            
            Button:
                text: root.get_text('shop')
                background_color: (0.2, 0.6, 1, 1)
                font_size: '20sp'
                size_hint: (0.8, None)
                height: dp(50)
                pos_hint: {"center_x": 0.5}
                on_release: root.open_shop()
            
            Button:
                text: root.get_text('settings')
                font_size: '20sp'
                size_hint: (0.8, None)
                height: dp(50)
                pos_hint: {"center_x": 0.5}
                on_release: root.open_settings()
            
            Button:
                text: root.get_text('exit')
                font_size: '20sp'
                size_hint: (0.8, None)
                height: dp(50)
                pos_hint: {"center_x": 0.5}
                on_release: app.stop()

<SettingsScreen>:
    BoxLayout:
        orientation: 'vertical'
        spacing: dp(10)
        padding: dp(20)
        
        Label:
            text: root.get_text('settings')
            font_size: '24sp'
            size_hint_y: None
            height: dp(50)
        
        BoxLayout:
            orientation: 'vertical'
            spacing: dp(10)
            size_hint_y: None
            height: self.minimum_height
            
            Button:
                id: lang_btn
                text: root.lang_text
                size_hint_y: None
                height: dp(50)
                on_release: root.toggle_language()
            
            Label:
                text: root.get_text('music_volume')
                size_hint_y: None
                height: dp(30)
            
            Slider:
                id: music_slider
                min: 0
                max: 1
                value: root.music_volume
                size_hint_y: None
                height: dp(40)
                on_value: root.on_music_volume_change(self.value)
            
            Label:
                text: root.get_text('sfx_volume')
                size_hint_y: None
                height: dp(30)
            
            Slider:
                id: sfx_slider
                min: 0
                max: 1
                value: root.sfx_volume
                size_hint_y: None
                height: dp(40)
                on_value: root.on_sfx_volume_change(self.value)
            
            Button:
                text: root.get_text('watch_ad')
                size_hint_y: None
                height: dp(50)
                background_color: (1, 0.6, 0, 1)
                on_release: root.show_rewarded_ad()
        
        Widget:
            # Пространство-заполнитель
            size_hint_y: 1
        
        Label:
            text: "satybaldybejbit@gmail.com"
            size_hint_y: None
            height: dp(30)
            color: (0.6, 0.6, 0.6, 1)
            font_size: '12sp'
        
        Button:
            text: root.get_text('back')
            size_hint: (1, None)
            height: dp(50)
            on_release: root.go_back()

<ShopScreen>:
    BoxLayout:
        orientation: 'vertical'
        spacing: dp(10)
        padding: dp(20)
        
        Label:
            text: root.get_text('shop')
            font_size: '24sp'
            size_hint_y: None
            height: dp(50)
        
        Label:
            text: root.coins_text
            font_size: '18sp'
            size_hint_y: None
            height: dp(30)
        
        ScrollView:
            GridLayout:
                id: shop_items
                cols: 1
                spacing: dp(10)
                size_hint_y: None
                height: self.minimum_height
        
        Button:
            text: root.get_text('back')
            size_hint: (1, None)
            height: dp(50)
            on_release: root.go_back()

<ShopItem>:
    orientation: 'vertical'
    size_hint_y: None
    height: dp(120)
    padding: dp(10)
    canvas.before:
        Color:
            rgba: (0.15, 0.15, 0.15, 1)
        Rectangle:
            pos: self.pos
            size: self.size
    
    Label:
        text: root.title
        font_size: '18sp'
        size_hint_y: None
        height: dp(30)
    
    Label:
        text: root.description
        font_size: '14sp'
        size_hint_y: None
        height: dp(40)
    
    BoxLayout:
        size_hint_y: None
        height: dp(40)
        
        Label:
            text: root.price
            size_hint_x: 0.6
        
        Button:
            text: root.get_text('buy')
            size_hint_x: 0.4
            background_color: (0.2, 0.8, 0.2, 1)
            on_release: root.purchase()

<GameOverPopup>:
    title: 'Game Over'
    size_hint: 0.8, 0.5
    auto_dismiss: False
    
    BoxLayout:
        orientation: 'vertical'
        spacing: dp(10)
        padding: dp(10)
        
        Label:
            text: root.score_text
            font_size: '20sp'
        
        BoxLayout:
            orientation: 'horizontal'
            size_hint_y: None
            height: dp(50)
            spacing: dp(10)
            
            Button:
                text: root.get_text('restart')
                on_release: root.restart_game()
            
            Button:
                text: root.get_text('continue')
                disabled: not root.can_continue
                on_release: root.continue_game()
        
        Button:
            text: root.get_text('watch_ad')
            size_hint_y: None
            height: dp(50)
            background_color: (1, 0.6, 0, 1)
            on_release: root.show_rewarded_ad()
        
        Button:
            text: root.get_text('back')
            size_hint_y: None
            height: dp(50)
            on_release: root.go_to_menu()
""")

class MainMenuScreen(Screen):
    coins_text = StringProperty("")
    
    def __init__(self, **kwargs):
        super(MainMenuScreen, self).__init__(**kwargs)
        self.update_coins_text()
    
    def on_pre_enter(self):
        """Вызывается перед показом экрана"""
        # Показать баннерную рекламу
        App.get_running_app().ad_manager.show_banner()
        self.update_coins_text()
    
    def on_leave(self):
        """Вызывается при уходе с экрана"""
        # Скрыть баннерную рекламу
        App.get_running_app().ad_manager.hide_banner()
    
    def update_coins_text(self):
        """Обновляет отображение количества монет"""
        self.coins_text = f"{self.get_text('coins')}: {App.get_running_app().game_store.coins}"
    
    def get_text(self, key):
        return LANGUAGES[current_lang].get(key, key)
    
    def play_game(self):
        self.play_click_sound()
        self.manager.current = 'game'
    
    def open_settings(self):
        self.play_click_sound()
        self.manager.current = 'settings'
    
    def open_shop(self):
        self.play_click_sound()
        self.manager.current = 'shop'
    
    def play_click_sound(self):
        click = SoundLoader.load('assets/click.wav')
        if click:
            click.volume = volume_sfx
            click.play()

class SettingsScreen(Screen):
    lang_text = StringProperty("")
    music_volume = NumericProperty(0.5)
    sfx_volume = NumericProperty(0.5)
    
    def __init__(self, **kwargs):
        super(SettingsScreen, self).__init__(**kwargs)
        self.update_lang_text()
        self.music_volume = volume_music
        self.sfx_volume = volume_sfx
    
    def on_pre_enter(self):
        """Вызывается перед показом экрана"""
        # Обновить настройки громкости
        self.music_volume = volume_music
        self.sfx_volume = volume_sfx
        self.update_lang_text()
        
        # Показать баннерную рекламу
        App.get_running_app().ad_manager.show_banner()
    
    def on_leave(self):
        """Вызывается при уходе с экрана"""
        # Скрыть баннерную рекламу
        App.get_running_app().ad_manager.hide_banner()
    
    def update_lang_text(self):
        """Обновляет текст кнопки языка"""
        self.lang_text = f"{self.get_text('language')}: {'Русский' if current_lang == 'ru' else 'English'}"
    
    def get_text(self, key):
        return LANGUAGES[current_lang].get(key, key)
    
    def toggle_language(self):
        global current_lang
        current_lang = 'en' if current_lang == 'ru' else 'ru'
        self.update_lang_text()
    
    def on_music_volume_change(self, value):
        global volume_music
        volume_music = value
    
    def on_sfx_volume_change(self, value):
        global volume_sfx
        volume_sfx = value
    
    def show_rewarded_ad(self):
        """Показывает рекламу с вознаграждением"""
        def on_reward():
            # Вознаграждение за просмотр рекламы - 50 монет
            App.get_running_app().game_store.add_coins(50)
            
            # Показать уведомление о получении награды
            popup = Popup(
                title=self.get_text('reward_received'),
                content=Label(text="+50 " + self.get_text('coins')),
                size_hint=(0.8, 0.3)
            )
            popup.open()
            Clock.schedule_once(lambda dt: popup.dismiss(), 2)
        
        App.get_running_app().ad_manager.show_rewarded_ad(on_reward)
    
    def go_back(self):
        """Возвращается на главный экран"""
        self.play_click_sound()
        self.manager.current = 'main'
    
    def play_click_sound(self):
        click = SoundLoader.load('assets/click.wav')
        if click:
            click.volume = volume_sfx
            click.play()

class ShopItem(BoxLayout):
    title = StringProperty("")
    description = StringProperty("")
    price = StringProperty("")
    product_key = StringProperty("")
    is_iap = BooleanProperty(False)
    coin_cost = NumericProperty(0)
    
    def __init__(self, title, description, price, product_key, is_iap=True, coin_cost=0, **kwargs):
        super(ShopItem, self).__init__(**kwargs)
        self.title = title
        self.description = description
        self.price = price
        self.product_key = product_key
        self.is_iap = is_iap
        self.coin_cost = coin_cost
    
    def get_text(self, key):
        return LANGUAGES[current_lang].get(key, key)
    
    def purchase(self):
        """Обрабатывает покупку предмета"""
        app = App.get_running_app()
        
        # Если это покупка за внутриигровую валюту
        if not self.is_iap:
            if app.game_store.spend_coins(self.coin_cost):
                self._process_purchase_reward()
                
                popup = Popup(
                    title=self.get_text('purchase_success'),
                    content=Label(text=self.title),
                    size_hint=(0.8, 0.3)
                )
                popup.open()
                Clock.schedule_once(lambda dt: popup.dismiss(), 2)
                
                # Обновить UI магазина
                if isinstance(self.parent.parent.parent, ShopScreen):
                    self.parent.parent.parent.update_shop_items()
            else:
                # Недостаточно монет
                popup = Popup(
                    title=self.get_text('purchase_failed'),
                    content=Label(text=f"{self.get_text('coins')}: {app.game_store.coins} / {self.coin_cost}"),
                    size_hint=(0.8, 0.3)
                )
                popup.open()
                Clock.schedule_once(lambda dt: popup.dismiss(), 2)
        else:
            # Если это покупка через Google Play
            def on_purchase_complete(result, product_key):
                if result == PurchaseResult.SUCCESS:
                    self._process_purchase_reward()
                    
                    popup = Popup(
                        title=self.get_text('purchase_success'),
                        content=Label(text=self.title),
                        size_hint=(0.8, 0.3)
                    )
                    popup.open()
                    Clock.schedule_once(lambda dt: popup.dismiss(), 2)
                    
                    # Обновить UI магазина
                    if isinstance(self.parent.parent.parent, ShopScreen):
                        self.parent.parent.parent.update_shop_items()
                elif result == PurchaseResult.FAILED:
                    popup = Popup(
                        title=self.get_text('purchase_failed'),
                        content=Label(text=""),
                        size_hint=(0.8, 0.3)
                    )
                    popup.open()
                    Clock.schedule_once(lambda dt: popup.dismiss(), 2)
            
            app.iap_manager.purchase(self.product_key, on_purchase_complete)
    
    def _process_purchase_reward(self):
        """Обрабатывает награду за покупку"""
        app = App.get_running_app()
        
        if self.product_key == 'no_ads':
            app.game_store.remove_ads()
            app.ad_manager.set_ads_removed(True)
        elif self.product_key == 'coins_100':
            app.game_store.add_coins(100)
        elif self.product_key == 'coins_500':
            app.game_store.add_coins(500)
        elif self.product_key == 'premium_skin':
            app.game_store.unlock_premium_skin()
        elif self.product_key == 'extra_lives':
            app.game_store.add_extra_lives(3)

class ShopScreen(Screen):
    coins_text = StringProperty("")
    
    def __init__(self, **kwargs):
        super(ShopScreen, self).__init__(**kwargs)
        self.update_coins_text()
    
    def on_pre_enter(self):
        """Вызывается перед показом экрана"""
        self.update_coins_text()
        self.update_shop_items()
        
        # Показать баннерную рекламу
        App.get_running_app().ad_manager.show_banner()
    
    def on_leave(self):
        """Вызывается при уходе с экрана"""
        # Скрыть баннерную рекламу
        App.get_running_app().ad_manager.hide_banner()
    
    def update_coins_text(self):
        """Обновляет отображение количества монет"""
        self.coins_text = f"{self.get_text('coins')}: {App.get_running_app().game_store.coins}"
    
    def update_shop_items(self):
        """Обновляет список товаров в магазине"""
        shop_items = self.ids.shop_items
        shop_items.clear_widgets()
        
        app = App.get_running_app()
        iap_manager = app.iap_manager
        game_store = app.game_store
        
        # Добавляем товары из Google Play
        if not game_store.no_ads:
            item = ShopItem(
                title=self.get_text('no_ads'),
                description=self.get_text('no_ads'),
                price=iap_manager.get_product_price('no_ads'),
                product_key='no_ads',
                is_iap=True
            )
            shop_items.add_widget(item)
        
        item = ShopItem(
            title="100 " + self.get_text('coins'),
            description=self.get_text('coin_pack'),
            price=iap_manager.get_product_price('coins_100'),
            product_key='coins_100',
            is_iap=True
        )
        shop_items.add_widget(item)
        
        item = ShopItem(
            title="500 " + self.get_text('coins'),
            description=self.get_text('coin_pack'),
            price=iap_manager.get_product_price('coins_500'),
            product_key='coins_500',
            is_iap=True
        )
        shop_items.add_widget(item)
        
        if not game_store.has_premium_skin:
            item = ShopItem(
                title=self.get_text('premium_skin'),
                description=self.get_text('premium_skin'),
                price=iap_manager.get_product_price('premium_skin'),
                product_key='premium_skin',
                is_iap=True
            )
            shop_items.add_widget(item)
        
        item = ShopItem(
            title=self.get_text('extra_lives'),
            description="3 " + self.get_text('extra_lives'),
            price=iap_manager.get_product_price('extra_lives'),
            product_key='extra_lives',
            is_iap=True
        )
        shop_items.add_widget(item)
        
        # Добавляем товары за внутриигровую валюту
        item = ShopItem(
            title=self.get_text('extra_lives'),
            description="1 " + self.get_text('extra_lives'),
            price="50 " + self.get_text('coins'),
            product_key='extra_life_coins',
            is_iap=False,
            coin_cost=50
        )
        shop_items.add_widget(item)
    
    def get_text(self, key):
        return LANGUAGES[current_lang].get(key, key)
    
    def go_back(self):
        """Возвращается на главный экран"""
        self.play_click_sound()
        self.manager.current = 'main'
    
    def play_click_sound(self):
        click = SoundLoader.load('assets/click.wav')
        if click:
            click.volume = volume_sfx
            click.play()

class Platform(Widget):
    """Платформа для игры"""
    pass

class Stickman(Image):
    """Игровой персонаж"""
    velocity_y = NumericProperty(0)
    
    def update(self, dt):
        self.y += self.velocity_y
        self.velocity_y -= 0.5
        if self.y < 0:
            self.y = 0
            self.velocity_y = 15

class GameOverPopup(Popup):
    score_text = StringProperty("")
    can_continue = BooleanProperty(False)
    
    def __init__(self, score, **kwargs):
        super(GameOverPopup, self).__init__(**kwargs)
        self.score = score
        self.score_text = f"{self.get_text('coins')}: +{score}"
        self.can_continue = App.get_running_app().game_store.extra_lives > 0
    
    def get_text(self, key):
        return LANGUAGES[current_lang].get(key, key)
    
    def restart_game(self):
        """Перезапускает игру"""
        self.dismiss()
        self.game_screen.reset_game()
    
    def continue_game(self):
        """Продолжает игру, используя дополнительную жизнь"""
        if App.get_running_app().game_store.use_extra_life():
            self.dismiss()
            self.game_screen.continue_game()
        else:
            self.can_continue = False
    
    def go_to_menu(self):
        """Возвращается в главное меню"""
        self.dismiss()
        self.game_screen.manager.current = 'main'
    
    def show_rewarded_ad(self):
        """Показывает рекламу с вознаграждением"""
        def on_reward():
            # Вознаграждение - продолжение игры
            self.dismiss()
            self.game_screen.continue_game()
        
        App.get_running_app().ad_manager.show_rewarded_ad(on_reward)

class GameScreen(Screen):
    score = NumericProperty(0)
    
    def __init__(self, **kwargs):
        super(GameScreen, self).__init__(**kwargs)
        self.reset_game()
    
    def on_pre_enter(self):
        """Вызывается перед показом экрана"""
        # При запуске новой игры с некоторой вероятностью показать межстраничную рекламу
        if randint(1, 3) == 1:  # 33% вероятность
            App.get_running_app().ad_manager.show_interstitial()
    
    def reset_game(self):
        """Сбрасывает игру в начальное состояние"""
        self.clear_widgets()
        self.layout = BoxLayout()
        self.score = 0
        
        # Создаем персонажа
        if App.get_running_app().game_store.has_premium_skin:
            self.stickman = Stickman(source='assets/premium_stickman.png', size_hint=(None, None), size=(50, 50), pos=(200, 100))
        else:
            self.stickman = Stickman(source='assets/stickman.png', size_hint=(None, None), size=(50, 50), pos=(200, 100))
            
        self.layout.add_widget(self.stickman)
        
        # Создаем платформы
        self.platforms = []
        for i in range(10):
            p = Platform(size=(60, 20), size_hint=(None, None))
            p.x = randint(0, Window.width - 60)
            p.y = i * 120
            p.canvas.before.clear()
            with p.canvas.before:
                from kivy.graphics import Color, Rectangle
                Color(0.4, 0.3, 0.2, 1)
                Rectangle(pos=p.pos, size=p.size)
            self.layout.add_widget(p)
            self.platforms.append(p)
        
        # Добавляем счетчик очков
        self.score_label = Label(
            text="0",
            size_hint=(None, None),
            size=(100, 50),
            pos=(10, Window.height - 60),
            font_size='20sp'
        )
        self.layout.add_widget(self.score_label)
        
        self.add_widget(self.layout)
        Clock.schedule_interval(self.update, 1/60.)
    
    def continue_game(self):
        """Продолжает игру после проигрыша"""
        # Даем небольшой импульс персонажу
        self.stickman.velocity_y = 15
        
        # Добавляем немного платформ, если их мало
        while len(self.platforms) < 10:
            p = Platform(size=(60, 20), size_hint=(None, None))
            p.x = randint(0, Window.width - 60)
            p.y = max([plat.y for plat in self.platforms]) + 120
            p.canvas.before.clear()
            with p.canvas.before:
                from kivy.graphics import Color, Rectangle
                Color(0.4, 0.3, 0.2, 1)
                Rectangle(pos=p.pos, size=p.size)
            self.layout.add_widget(p)
            self.platforms.append(p)
    
    def update(self, dt):
        """Обновляет состояние игры"""
        self.stickman.update(dt)
        
        # Проверяем столкновения с платформами
        if self.stickman.velocity_y < 0:
            for platform in self.platforms:
                if (self.stickman.y < platform.y + platform.height and
                    self.stickman.y > platform.y and
                    self.stickman.x + self.stickman.width > platform.x and
                    self.stickman.x < platform.x + platform.width):
                    self.stickman.velocity_y = 15
                    break
        
        # Прокрутка камеры вверх при подъеме персонажа
        if self.stickman.y > Window.height / 2:
            offset = self.stickman.y - Window.height / 2
            self.stickman.y -= offset
            for platform in self.platforms:
                platform.y -= offset
                
                # Увеличиваем счет при прокрутке
                self.score += int(offset / 10)
                self.score_label.text = str(self.score)
                
                # Если платформа выходит за нижнюю границу, перемещаем ее наверх
                if platform.y < 0:
                    platform.y += Window.height + 100
                    platform.x = randint(0, Window.width - 60)
        
        # Проверяем проигрыш (персонаж упал вниз)
        if self.stickman.y < -self.stickman.height:
            Clock.unschedule(self.update)
            self.game_over()
    
    def game_over(self):
        """Обрабатывает конец игры"""
        # Начисляем монеты за очки
        coins_earned = int(self.score / 10)
        App.get_running_app().game_store.add_coins(coins_earned)
        
        # Создаем и показываем всплывающее окно окончания игры
        popup = GameOverPopup(coins_earned)
        popup.game_screen = self
        popup.open()
        
        # С вероятностью 50% показываем межстраничную рекламу
        if randint(1, 2) == 1:
            App.get_running_app().ad_manager.show_interstitial()

class MyApp(App):
    def build(self):
        # Инициализируем хранилище для игровых данных
        self.game_store = GameStore()
        
        # Инициализируем менеджер рекламы
        self.ad_manager = AdManager()
        self.ad_manager.set_ads_removed(self.game_store.no_ads)
        
        # Инициализируем менеджер внутриигровых покупок
        self.iap_manager = IAPManager()
        
        # Создаем менеджер экранов
        sm = ScreenManager(transition=FadeTransition())
        sm.add_widget(MainMenuScreen(name='main'))
        sm.add_widget(SettingsScreen(name='settings'))
        sm.add_widget(ShopScreen(name='shop'))
        sm.add_widget(GameScreen(name='game'))
        
        return sm
    
    def on_pause(self):
        """Вызывается при сворачивании приложения"""
        return True  # Предотвращает закрытие приложения
    
    def on_resume(self):
        """Вызывается при восстановлении приложения после сворачивания"""
        pass

if __name__ == '__main__':
    MyApp().run()
