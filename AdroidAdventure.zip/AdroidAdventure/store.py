from kivy.properties import NumericProperty, BooleanProperty
from kivy.event import EventDispatcher
from kivy.logger import Logger
from kivy.storage.jsonstore import JsonStore
from kivy.clock import Clock
import os

class GameStore(EventDispatcher):
    """
    Класс для хранения игровых данных и прогресса
    """
    
    coins = NumericProperty(0)
    premium = BooleanProperty(False)
    no_ads = BooleanProperty(False)
    extra_lives = NumericProperty(0)
    has_premium_skin = BooleanProperty(False)
    
    def __init__(self):
        """Инициализирует хранилище игровых данных"""
        super(GameStore, self).__init__()
        
        # Создаем путь к файлу данных
        self.store_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'gamedata.json')
        self.store = JsonStore(self.store_file)
        
        # Загружаем сохраненные данные
        self.load_data()
        
        # Регистрируем свойства для автоматического сохранения при изменении
        self.bind(
            coins=self.on_property_change,
            premium=self.on_property_change,
            no_ads=self.on_property_change,
            extra_lives=self.on_property_change,
            has_premium_skin=self.on_property_change
        )
    
    def load_data(self):
        """Загружает данные из постоянного хранилища"""
        try:
            if self.store.exists('gamedata'):
                data = self.store.get('gamedata')
                self.coins = data.get('coins', 0)
                self.premium = data.get('premium', False)
                self.no_ads = data.get('no_ads', False)
                self.extra_lives = data.get('extra_lives', 0)
                self.has_premium_skin = data.get('has_premium_skin', False)
                Logger.info(f"GameStore: Данные загружены: {data}")
            else:
                Logger.info("GameStore: Используются значения по умолчанию")
                self.save_data()
        except Exception as e:
            Logger.error(f"GameStore: Ошибка загрузки данных: {e}")
            # Сбрасываем к значениям по умолчанию
            self.coins = 0
            self.premium = False
            self.no_ads = False
            self.extra_lives = 0
            self.has_premium_skin = False
            self.save_data()
    
    def save_data(self):
        """Сохраняет данные в постоянное хранилище"""
        try:
            data = {
                'coins': self.coins,
                'premium': self.premium,
                'no_ads': self.no_ads,
                'extra_lives': self.extra_lives,
                'has_premium_skin': self.has_premium_skin
            }
            self.store.put('gamedata', **data)
            Logger.info(f"GameStore: Данные сохранены: {data}")
        except Exception as e:
            Logger.error(f"GameStore: Ошибка сохранения данных: {e}")
    
    def on_property_change(self, *args):
        """Вызывается при изменении свойств класса"""
        # Используем Clock для отложенного сохранения,
        # чтобы не сохранять при каждом изменении
        Clock.unschedule(self.save_data)
        Clock.schedule_once(lambda dt: self.save_data(), 0.5)
    
    def add_coins(self, amount):
        """
        Добавляет монеты игроку
        
        :param amount: Количество монет для добавления
        """
        self.coins += amount
        Logger.info(f"GameStore: Добавлено {amount} монет, всего: {self.coins}")
    
    def spend_coins(self, amount):
        """
        Тратит монеты игрока
        
        :param amount: Количество монет для траты
        :return: True если успешно, False если недостаточно монет
        """
        if self.coins >= amount:
            self.coins -= amount
            Logger.info(f"GameStore: Потрачено {amount} монет, осталось: {self.coins}")
            return True
        else:
            Logger.warning(f"GameStore: Недостаточно монет (нужно: {amount}, есть: {self.coins})")
            return False
    
    def add_extra_lives(self, count):
        """
        Добавляет дополнительные жизни
        
        :param count: Количество жизней для добавления
        """
        self.extra_lives += count
        Logger.info(f"GameStore: Добавлено {count} жизней, всего: {self.extra_lives}")
    
    def use_extra_life(self):
        """
        Использует дополнительную жизнь
        
        :return: True если успешно, False если нет дополнительных жизней
        """
        if self.extra_lives > 0:
            self.extra_lives -= 1
            Logger.info(f"GameStore: Использована дополнительная жизнь, осталось: {self.extra_lives}")
            return True
        else:
            Logger.warning("GameStore: Нет дополнительных жизней")
            return False
    
    def unlock_premium_skin(self):
        """Разблокирует премиум скин"""
        self.has_premium_skin = True
        Logger.info("GameStore: Премиум скин разблокирован")
    
    def remove_ads(self):
        """Убирает рекламу"""
        self.no_ads = True
        Logger.info("GameStore: Реклама отключена")
